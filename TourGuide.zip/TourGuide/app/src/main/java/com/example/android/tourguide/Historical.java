package com.example.android.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class Historical extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("10AM to 5PM 256-546-7365 ", "Gadsden Museum of Art - Visual Art Exhibits",R.drawable.art));
        words.add(new Word("6AM to 6PM    256-549-4500 ", "James D. Martin Wildlife Park - Nature",R.drawable.bird));
        words.add(new Word("8AM to 5PM    256-547-8696", "Downtown Gadsden Inc. - Information on Landmarks",R.drawable.landmark));
        words.add(new Word("10AM to 5PM 256-543-2787", "Imagination Place - Children's interactive exhibits ",R.drawable.imagination));

        WordAdapter adapter =
                new WordAdapter( this, words, R.color.category_historical);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

    }
}

