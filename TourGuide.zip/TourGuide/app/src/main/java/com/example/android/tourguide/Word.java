package com.example.android.tourguide;


public class Word {


    private String mDefaultTranslation;


    private String mTourTranslation;


    private int mImageResourceId= NO_IMAGE_PROVIDED;

    private static final int NO_IMAGE_PROVIDED = 0;




    public Word(String defaultTranslation, String tourTranslation) {
        mDefaultTranslation = defaultTranslation;
        mTourTranslation = tourTranslation;
    }


    public Word(String defaultTranslation, String tourTranslation, int imageResourceId) {
        mDefaultTranslation = defaultTranslation;
        mTourTranslation = tourTranslation;
        mImageResourceId = imageResourceId;
    }


    public String getDefaultTranslation() {
        return mDefaultTranslation;
    }


    public String getTourTranslation() {
        return mTourTranslation;
    }


    public int getmImageResourceId() {
        return mImageResourceId;
    }


    public boolean hasImage(){
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }
}
