package com.example.android.tourguide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;


public class Hotels extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("All hotels listed have an outside pool and a free breakfast", "Call the location for a current breakfast menu."));
        words.add(new Word("106 Walker St, Gadsden, AL 35904 256-691-0225", "Holiday Inn - From $94 per night"));
        words.add(new Word("129 River Rd, Gadsden, AL 35901 256-546-2337", "Hampton Inn - From $90 per night"));
        words.add(new Word("1600 Rainbow Dr, Gadsden, AL 3590 937-327-6512", "Red Roof Inn - From $60 per night"));
        words.add(new Word("116 Walker St, Gadsden, AL 35904 256-538-2100", "Fairfield Inn - From $92 per night"));

        WordAdapter adapter =
                new WordAdapter( this, words, R.color.category_hotels);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

    }
}
