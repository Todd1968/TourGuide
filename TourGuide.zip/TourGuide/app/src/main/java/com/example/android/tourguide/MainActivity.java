package com.example.android.tourguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        TextView numbers = (TextView) findViewById(R.id.restaurants);

        numbers.setOnClickListener(new OnClickListener() {
            // The code in this method will be executed when the numbers category is clicked on.
            @Override
            public void onClick(View view) {

                Intent numbersIntent = new Intent(MainActivity.this, Restaurants.class);

                startActivity(numbersIntent);
            }
        });

        TextView family = (TextView) findViewById(R.id.historical);

        family.setOnClickListener(new OnClickListener() {
            // The code in this method will be executed when the family category is clicked on.
            @Override
            public void onClick(View view) {

                Intent familyIntent = new Intent(MainActivity.this, Historical.class);

                startActivity(familyIntent);
            }
        });

        TextView colors = (TextView) findViewById(R.id.entertainment);

        colors.setOnClickListener(new OnClickListener() {
            // The code in this method will be executed when the colors category is clicked on.
            @Override
            public void onClick(View view) {

                Intent colorsIntent = new Intent(MainActivity.this, Entertainment.class);

                startActivity(colorsIntent);
            }
        });

        TextView phrases = (TextView) findViewById(R.id.hotels);

        phrases.setOnClickListener(new OnClickListener() {
            // The code in this method will be executed when the phrases category is clicked on.
            @Override
            public void onClick(View view) {

                Intent phrasesIntent = new Intent(MainActivity.this, Hotels.class);

                startActivity(phrasesIntent);
            }
        });


    }
}
