package com.example.android.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import java.util.ArrayList;

public class Restaurants extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);


        ArrayList<Word> words = new ArrayList<Word>();

        words.add(new Word("11AM to 10PM  256-543-2086", "Red Lobster - Seafood",R.drawable.fish));

        words.add(new Word("10AM to 11PM  256-546-6088", "El Tap II - Mexican",R.drawable.taco));

        words.add(new Word("10AM to 10PM  256-543-0470", "Logan's Roadhouse - Steak",R.drawable.steak));

        words.add(new Word("6AM to 9PM     256-543-7770", "Chick-Fil-A - Sandwich",R.drawable.chick));



        WordAdapter adapter =
                new WordAdapter( this, words, R.color.category_restaurants);


        ListView listView = (ListView) findViewById(R.id.list);


        listView.setAdapter(adapter);

    }
}
