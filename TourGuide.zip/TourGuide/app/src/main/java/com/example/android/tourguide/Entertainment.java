package com.example.android.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import java.util.ArrayList;

public class Entertainment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("3PM to 9PM    256-312-8974", "The Factory - Trampoline playhouse ",R.drawable.factory));
        words.add(new Word("11AM to 8PM    256-467-3794", "Knockerball Gadsden - Play games in life size blowup balls",R.drawable.knockerball));
        words.add(new Word("7AM to 7PM    256-546-0451", "Gadsden Country Club - Golf Course",R.drawable.golf));
        words.add(new Word("2PM to 2AM    256-546-4229", "Chestnut Station - Live Music and Spirits",R.drawable.music));

        WordAdapter adapter = new WordAdapter( this, words, R.color.category_entertainment);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(adapter);

    }
}